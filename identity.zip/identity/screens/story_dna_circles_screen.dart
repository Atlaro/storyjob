// lib/features/identity/screens/story_dna_circles_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:storyjob/core/services/audio_service.dart';
import 'package:storyjob/core/theme/storyjob_theme.dart';
import 'package:storyjob/core/widgets/story_level_tracker_widget.dart';
import 'package:storyjob/features/identity/models/story_identity.dart';
import 'package:storyjob/features/identity/services/story_identity_service.dart';
import 'package:storyjob/features/record/screens/story_recording_screen.dart';

class StoryDnaCirclesScreen extends StatefulWidget {
  final VoidCallback? onOpenMatches;

  const StoryDnaCirclesScreen({
    super.key,
    this.onOpenMatches,
  });

  @override
  State<StoryDnaCirclesScreen> createState() => _StoryDnaCirclesScreenState();
}

class _StoryDnaCirclesScreenState extends State<StoryDnaCirclesScreen>
    with SingleTickerProviderStateMixin {
  final StoryIdentityService _identityService = StoryIdentityService();
  bool _isPlayingAudioDna = false;
  bool _isLoading = true;
  late StoryIdentity _identity;

  late final AnimationController _pulseController;
  late final Animation<double> _pulseScale;

  final StoryIdentity _fallbackIdentity = const StoryIdentity(
    interests: ['Ehrenamt & Hilfsorganisation', 'Handwerk & Bauen', 'Coding & Systeme'],
    values: ['Augenhöhe', 'Eigenverantwortung', 'Verlässlichkeit', 'Hands-on-Mentalität'],
    goals: ['Etwas Sinnvolles bewegen', 'Projekte mit echter Wirkung leiten'],
    workstyle: ['Hands-on anpacken', 'Autonom tüfteln', 'Im Team auf Augenhöhe'],
    motivators: ['Sinnstiftende Aufgaben', 'Miteinander auf Augenhöhe', 'Werte-Einklang'],
    strengths: ['Analytisches Denken', 'Einsatzbereitschaft', 'Kommunikation'],
    communities: ['Ehrenamt & Katastrophenschutz', 'Regionale Macher'],
    learningInterests: ['Zukunftstechnologien', 'Praxis-Führung'],
    impactVision: 'Arbeit, Menschlichkeit und echte Werte im Einklang gestalten.',
  );

  final List<Map<String, dynamic>> _resonanceCircles = [
    {
      'title': 'Nachhaltigkeit & Energie',
      'tag': '🌱',
      'reason': 'Basiert auf deinen Werten & Wirkungszielen',
      'joined': true,
      'color': StoryJobTheme.emeraldGreen,
    },
    {
      'title': 'Ehrenamt, Einsatz & Vereine',
      'tag': '🚒',
      'reason': 'Basiert auf Verlässlichkeit, Schutz & Haltung',
      'joined': true,
      'color': StoryJobTheme.champagneGold,
    },
    {
      'title': 'Zukunftstechnologie & Handwerk',
      'tag': '⚡',
      'reason': 'Basiert auf Wachstumsfeldern & Innovation',
      'joined': false,
      'color': StoryJobTheme.cyanAccent,
    },
    {
      'title': 'Regionale Initiativen & Macher',
      'tag': '🏡',
      'reason': 'Basiert auf lokaler Verwurzelung & Hands-on-Spirit',
      'joined': false,
      'color': StoryJobTheme.primaryViolet,
    },
  ];

  @override
  void initState() {
    super.initState();
    _identity = _fallbackIdentity;
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);

    _pulseScale = Tween<double>(begin: 0.94, end: 1.06).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _loadUserIdentity();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    if (_isPlayingAudioDna) {
      AudioService.stopAudio();
    }
    super.dispose();
  }

  Future<void> _loadUserIdentity() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final loaded = await _identityService.loadIdentity(uid);
      if (loaded != null && mounted) {
        setState(() {
          _identity = loaded;
        });
      }
    }
    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _toggleAudioDna() async {
    HapticFeedback.lightImpact();
    if (_isPlayingAudioDna) {
      await AudioService.stopAudio();
      if (mounted) setState(() => _isPlayingAudioDna = false);
    } else {
      await AudioService.stopAudio();
      if (mounted) setState(() => _isPlayingAudioDna = true);

      if (!mounted) return;

      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 18),
              SizedBox(width: 10),
              Text(
                'Audio-DNA wird wiedergegeben...',
                style: TextStyle(color: StoryJobTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF161822),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: StoryJobTheme.cardBorder),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _shareStoryResume() {
    HapticFeedback.mediumImpact();
    final user = FirebaseAuth.instance.currentUser;
    final handle = user?.displayName != null
        ? user!.displayName!.toLowerCase().replaceAll(' ', '')
        : 'macher';

    Clipboard.setData(ClipboardData(text: 'https://storyjob.de/@$handle'));

    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Link kopiert: storyjob.de/@$handle',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: StoryJobTheme.textPrimary),
        ),
        backgroundColor: const Color(0xFF161822),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: StoryJobTheme.cardBorder),
        ),
      ),
    );
  }

  Future<void> _toggleTagInList(
    List<String> currentList,
    String tag,
    Function(List<String>) onUpdate,
  ) async {
    HapticFeedback.selectionClick();
    final updated = List<String>.from(currentList);
    if (updated.contains(tag)) {
      if (updated.length > 1) {
        updated.remove(tag);
      }
    } else {
      updated.add(tag);
    }
    onUpdate(updated);

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      await _identityService.saveIdentity(uid, _identity);
    }
  }

  void _showAddCustomTagSheet() {
    HapticFeedback.lightImpact();
    final controller = TextEditingController();

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF161822),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.fromLTRB(22, 20, 22, MediaQuery.of(ctx).viewInsets.bottom + 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Eigenen Werte-Anker ergänzen',
                style: TextStyle(
                  color: StoryJobTheme.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Benenne eine Facette, die dich ausmacht (z. B. Krisenfestigkeit, Mentoring).',
                style: TextStyle(color: StoryJobTheme.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                autofocus: true,
                style: const TextStyle(color: StoryJobTheme.textPrimary),
                decoration: InputDecoration(
                  hintText: 'Z. B. Krisenfestigkeit',
                  hintStyle: const TextStyle(color: StoryJobTheme.textMuted),
                  filled: true,
                  fillColor: StoryJobTheme.cardSurface,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: StoryJobTheme.cardBorder),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: StoryJobTheme.cyanAccent),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    final text = controller.text.trim();
                    if (text.isNotEmpty) {
                      _toggleTagInList(_identity.values, text, (vals) {
                        setState(() => _identity = _identity.copyWith(values: vals));
                      });
                      Navigator.pop(ctx);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: StoryJobTheme.primaryViolet,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Anker sichern', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: StoryJobTheme.backgroundBase,
        body: Center(child: CircularProgressIndicator(color: StoryJobTheme.cyanAccent)),
      );
    }

    final completeness = _identity.completenessPercent;

    return Scaffold(
      backgroundColor: StoryJobTheme.backgroundBase,
      body: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18.0, 14.0, 18.0, 110.0),
          children: [
            // 1. Header mit StoryJob DNA Badge & Teilen
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 38,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF161822),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: StoryJobTheme.cardBorder),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.fingerprint_rounded, color: StoryJobTheme.cyanAccent, size: 16),
                      SizedBox(width: 6),
                      Text(
                        'StoryJob DNA',
                        style: TextStyle(
                          color: StoryJobTheme.textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _shareStoryResume,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF161822),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: StoryJobTheme.cardBorder),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.share_outlined, color: StoryJobTheme.cyanAccent, size: 15),
                        SizedBox(width: 6),
                        Text(
                          'Teilen',
                          style: TextStyle(
                            color: StoryJobTheme.textPrimary,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            // 2. DNA Tracker (Zepp-Style Elevation)
            StoryLevelTrackerWidget(
              dnaCompleteness: completeness,
              storiesRecorded: _identity.interests.length,
              activeValuesCount: _identity.values.length,
              onDeepenStory: _showAddCustomTagSheet,
            ),
            const SizedBox(height: 16),

            // 3. Audio-DNA Player
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF161822),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: _isPlayingAudioDna
                      ? StoryJobTheme.cyanAccent.withValues(alpha: 0.55)
                      : StoryJobTheme.cyanAccent.withValues(alpha: 0.25),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.40),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                  if (_isPlayingAudioDna)
                    BoxShadow(
                      color: StoryJobTheme.cyanAccent.withValues(alpha: 0.15),
                      blurRadius: 20,
                      spreadRadius: 1,
                    ),
                ],
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: _toggleAudioDna,
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: StoryJobTheme.cyanAccent.withValues(alpha: 0.16),
                        border: Border.all(color: StoryJobTheme.cyanAccent.withValues(alpha: 0.45)),
                      ),
                      child: Icon(
                        _isPlayingAudioDna ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: StoryJobTheme.cyanAccent,
                        size: 26,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Audio-DNA',
                          style: TextStyle(
                            color: StoryJobTheme.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _isPlayingAudioDna ? 'Wiedergabe aktiv • Resonanz spürbar' : '01:43 Min. • Haltung & Ausstrahlung',
                          style: TextStyle(
                            color: _isPlayingAudioDna ? StoryJobTheme.cyanAccent : StoryJobTheme.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.mic_none_rounded, color: StoryJobTheme.textSecondary, size: 21),
                    tooltip: 'Neu aufnehmen',
                    onPressed: () {
                      HapticFeedback.mediumImpact();
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const StoryRecordingScreen()),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // 4. Statuszeile zur Resonanz
            GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                widget.onOpenMatches?.call();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFF161822),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: StoryJobTheme.primaryViolet.withValues(alpha: 0.35)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.35),
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseScale,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: _pulseScale.value,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: StoryJobTheme.primaryViolet,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: StoryJobTheme.primaryViolet.withValues(alpha: 0.7),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'KI-Resonanz aktiv',
                            style: TextStyle(
                              color: StoryJobTheme.textPrimary,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Matches entstehen durch Taten, Haltung & echte Leidenschaft.',
                            style: TextStyle(color: StoryJobTheme.textSecondary, fontSize: 11.5),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded, color: StoryJobTheme.textMuted, size: 12),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 26),

            // 5. Sektion: Werte & Haltung (Violett)
            _buildInteractivePillSection(
              title: 'Werte & menschliche Haltung',
              subtitle: 'Das Fundament: Wonach entscheidest und handelst du?',
              accentColor: StoryJobTheme.primaryViolet,
              currentItems: _identity.values,
              suggestions: const [
                'Augenhöhe',
                'Eigenverantwortung',
                'Verlässlichkeit',
                'Hands-on-Mentalität',
                'Fehlerkultur',
                'Transparenz',
                'Echtheit',
                'Krisenfestigkeit',
              ],
              onToggle: (tag) => _toggleTagInList(_identity.values, tag, (list) {
                setState(() => _identity = _identity.copyWith(values: list));
              }),
              onAddCustom: _showAddCustomTagSheet,
            ),
            const SizedBox(height: 24),

            // 6. Sektion: Echte Leidenschaften & Machen (Cyan)
            _buildInteractivePillSection(
              title: 'Echte Leidenschaften & Machen',
              subtitle: 'Wo brennt dein Feuer abseits von Zertifikaten?',
              accentColor: StoryJobTheme.cyanAccent,
              currentItems: _identity.interests,
              suggestions: const [
                'Ehrenamt & Hilfsorganisation',
                'Handwerk & Bauen',
                'Coding & Systeme',
                'Erneuerbare Energien',
                'Teamführung im Verein',
                'Kreatives Schaffen',
                'Ausdauersport',
                'Regionale Macher',
              ],
              onToggle: (tag) => _toggleTagInList(_identity.interests, tag, (list) {
                setState(() => _identity = _identity.copyWith(interests: list));
              }),
            ),
            const SizedBox(height: 24),

            // 7. Sektion: Arbeitsstil & Wirkungsmodus (Gold)
            _buildInteractivePillSection(
              title: 'Wirkungsmodus & Arbeitsstil',
              subtitle: 'In welchem Umfeld entfaltest du deine volle Energie?',
              accentColor: StoryJobTheme.champagneGold,
              currentItems: _identity.workstyle,
              suggestions: const [
                'Hands-on anpacken',
                'Autonom tüfteln',
                'Im Team auf Augenhöhe',
                'Flexible Arbeitsweise',
                'Struktur schaffen',
                'Verantwortung übernehmen',
              ],
              onToggle: (tag) => _toggleTagInList(_identity.workstyle, tag, (list) {
                setState(() => _identity = _identity.copyWith(workstyle: list));
              }),
            ),
            const SizedBox(height: 28),

            // 8. Resonanz-Kreise
            _buildSectionLabel('Resonanz-Kreise™'),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF161822),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: StoryJobTheme.cardBorder),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: List.generate(_resonanceCircles.length, (index) {
                  final circle = _resonanceCircles[index];
                  final bool isJoined = circle['joined'] as bool;
                  final Color circleColor = circle['color'] as Color? ?? StoryJobTheme.cyanAccent;
                  final bool isLast = index == _resonanceCircles.length - 1;

                  return Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            Text(circle['tag'] as String, style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    circle['title'] as String,
                                    style: const TextStyle(
                                      color: StoryJobTheme.textPrimary,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    circle['reason'] as String,
                                    style: const TextStyle(color: StoryJobTheme.textSecondary, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                HapticFeedback.selectionClick();
                                setState(() {
                                  circle['joined'] = !isJoined;
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isJoined
                                      ? circleColor.withValues(alpha: 0.16)
                                      : StoryJobTheme.backgroundBase,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: isJoined
                                        ? circleColor.withValues(alpha: 0.5)
                                        : StoryJobTheme.cardBorder,
                                  ),
                                ),
                                child: Text(
                                  isJoined ? 'Aktiv' : 'Verbinden',
                                  style: TextStyle(
                                    color: isJoined ? circleColor : StoryJobTheme.textSecondary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!isLast)
                        const Divider(
                          height: 1,
                          thickness: 1,
                          indent: 16,
                          endIndent: 16,
                          color: StoryJobTheme.cardBorder,
                        ),
                    ],
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: StoryJobTheme.textSecondary,
        fontWeight: FontWeight.w600,
        fontSize: 13,
        letterSpacing: 0.2,
      ),
    );
  }

  Widget _buildInteractivePillSection({
    required String title,
    required String subtitle,
    required Color accentColor,
    required List<String> currentItems,
    required List<String> suggestions,
    required Function(String) onToggle,
    VoidCallback? onAddCustom,
  }) {
    // Zusammenstellung aller anzuzeigenden Chips
    final allChips = {...currentItems, ...suggestions}.toList();

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF161822),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accentColor.withValues(alpha: 0.25), width: 1.1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: StoryJobTheme.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: const TextStyle(
              color: StoryJobTheme.textSecondary,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...allChips.map((chip) {
                final isSelected = currentItems.contains(chip);
                return GestureDetector(
                  onTap: () => onToggle(chip),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? accentColor.withValues(alpha: 0.20)
                          : StoryJobTheme.cardSurface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected
                            ? accentColor.withValues(alpha: 0.65)
                            : StoryJobTheme.cardBorder,
                        width: isSelected ? 1.3 : 1.0,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: accentColor.withValues(alpha: 0.15),
                                blurRadius: 8,
                              ),
                            ]
                          : [],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (isSelected) ...[
                          Icon(Icons.check_rounded, size: 13, color: accentColor),
                          const SizedBox(width: 5),
                        ],
                        Text(
                          chip,
                          style: TextStyle(
                            color: isSelected ? StoryJobTheme.textPrimary : StoryJobTheme.textSecondary,
                            fontSize: 12,
                            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              if (onAddCustom != null)
                GestureDetector(
                  onTap: onAddCustom,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: StoryJobTheme.cardSurface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: StoryJobTheme.cardBorder),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add_rounded, size: 14, color: accentColor),
                        const SizedBox(width: 4),
                        Text(
                          'Eigener Anker',
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}